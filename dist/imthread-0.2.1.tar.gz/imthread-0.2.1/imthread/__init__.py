from imthread.imthread import multi_threading, console_log

def stop():
    raise Exception('stop')



